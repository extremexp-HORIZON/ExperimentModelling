# Policy-based Data Augmentattion

## Introduction
This repository contains the code for a policy-based data augmentation project.


## Installation
The project is set up using `poetry` and the `pyproject.toml` file. The project is also set up to use `docker` and `docker-compose` to run 
the project in a container. The project is also set up to communicate with an API to get the data to be augmented.



