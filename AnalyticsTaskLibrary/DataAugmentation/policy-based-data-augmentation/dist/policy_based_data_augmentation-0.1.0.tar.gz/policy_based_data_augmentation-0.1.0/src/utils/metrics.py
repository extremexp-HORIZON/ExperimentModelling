from scipy.stats import wasserstein_distance
import pandas as pd 


def dataset_similarity(dataset_A: pd.DataFrame, dataset_B: pd.DataFrame) -> float:
    """
    Calculates the Wasserstein distance-based similarity between two datasets.

    Parameters:
    - dataset_A (pd.DataFrame): The first dataset for comparison.
    - dataset_B (pd.DataFrame): The second dataset for comparison.

    Returns:
       - mean_w_distance (float): The mean Wasserstein distance between corresponding feature distributions of the two datasets.
    """

    # Calculate the distance for each feature
    w_distances = {col: wasserstein_distance(dataset_A[col], dataset_B[col]) for col in dataset_A.columns}
    # Calculate the mean Wasserstein distance
    mean_w_distance = sum(w_distances.values()) / len(w_distances)

    return mean_w_distance
