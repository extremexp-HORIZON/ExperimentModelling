import pandas as pd

import src.data_augmentation.ctgan_algorithm as da_ctgan
import src.data_augmentation.smote_algorithm as da_smote
import src.data_augmentation.adasyn_algorithm as da_adasyn
import src.utils.metrics as metrics
import logging


def augment_data(dataset: pd.DataFrame, label: str, model_type: str, n_samples: int, verbose: bool = False) -> list:
    """
    Apply data augmentation to the input dataset using the specified model.

    Parameters:
    - dataset (pd.DataFrame): The input dataset to be augmented.
    - label (str): The label or target variable for the augmentation.
    - model_type (str): The type of model used for data augmentation. Supported types are "CTGAN", "SMOTE", and "ADASYN".
    - n_samples (int): The number of synthetic samples to generate during augmentation.
    - verbose (bool, optional): If True, display additional information during augmentation. Default is False.

    Returns:
    - pd.DataFrame: Augmented dataset containing synthetic samples.

    Raises:
    - ValueError: If an invalid model type is provided or if data augmentation fails.
    """
    log_level = logging.INFO if verbose else logging.WARNING
    logging.basicConfig(level=log_level)
    logger = logging.getLogger(__name__)
    
    original_samples = dataset.shape[0]
    
    if model_type == "AUTO": 
        augmented_data_ctgan = da_ctgan.ctgan_augmentation(dataset, label, n_samples)
        augmented_data_smote = da_smote.smote_augmentation(dataset, label, n_samples)
        augmented_data_adasyn = da_adasyn.adasyn_augmentation(dataset, label, n_samples)
        
        metric_smote = metrics.dataset_similarity(dataset, augmented_data_smote)
        metric_adasyn = metrics.dataset_similarity(dataset, augmented_data_adasyn)
        metric_ctgan = metrics.dataset_similarity(dataset, augmented_data_ctgan)
        
        logger.info(f"Applying DA using AUTO, Original Samples: {original_samples} - Generated Samples {n_samples}")
        logger.info(f"DA Quality Smote: {metric_smote}, Adasyn: {metric_adasyn} - CTGAN: {metric_adasyn}")

        # return the augmented data with more similarity to the original samples
        best_similarity_metric = max(metric_smote, metric_adasyn, metric_ctgan)

        if best_similarity_metric == metric_smote: return augmented_data_smote
        elif best_similarity_metric == metric_adasyn: return augmented_data_adasyn
        else: return augmented_data_ctgan
        

    elif model_type in ["CTGAN", "SMOTE", "ADASYN"]: 
        augmentation_methods = {
            "CTGAN": da_ctgan.ctgan_augmentation,
            "SMOTE": da_smote.smote_augmentation,
            "ADASYN": da_adasyn.adasyn_augmentation
        }
    
        if model_type in augmentation_methods:
            logger.info(f"Applying DA using {model_type}, Original Samples: {original_samples} - Generated Samples {n_samples}")
            augmented_data = augmentation_methods[model_type](dataset, label, n_samples)

    else:
        raise ValueError(f"Invalid model type: {model_type}")

    if augmented_data is None:
        logger.warning(f"Data augmentation failed for model type: {model_type}")
        raise ValueError(f"Data augmentation failed for model type: {model_type}")

    return augmented_data
